import { Component } from '@angular/core';

@Component({
  selector: 'app-center-nav',
  templateUrl: './center-nav.component.html',
  styleUrls: ['./center-nav.component.css']
})
export class CenterNavComponent {

}
