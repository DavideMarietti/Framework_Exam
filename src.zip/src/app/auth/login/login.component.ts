import { Component } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  // se non le avessi inizializzate qui:
  // "message": "Property 'username' has no initializer and is not definitely assigned in the constructor.",
	// "message": "Property 'password' has no initializer and is not definitely assigned in the constructor."
  username: string = '';
  password: string = '';

  onSubmit() {
    console.log('Username:', this.username);
    console.log('Password:', this.password);
  }
}
